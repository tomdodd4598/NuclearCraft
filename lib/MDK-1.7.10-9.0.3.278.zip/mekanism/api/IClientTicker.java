package mekanism.api;

public interface IClientTicker
{
	public void clientTick();

	public boolean needsTicks();
}
